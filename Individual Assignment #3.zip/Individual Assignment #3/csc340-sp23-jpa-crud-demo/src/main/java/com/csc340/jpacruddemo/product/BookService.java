package com.csc340.jpacruddemo.product;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 *
 * @author sentini
 */
@Service
public class BookService {

    @Autowired
    private BookRepository repo;

    public List<Book> getAllBooks() {
        return repo.findAll();
    }

    public Book getBook(long bookID) {
        return repo.getReferenceById(bookID);
    }

    public void deleteBook(long bookID) {
        repo.deleteById(bookID);
    }

    void saveBook(Book book) {
        repo.save(book);
    }
}
