package com.csc340.jpacruddemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JpaCrudDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
